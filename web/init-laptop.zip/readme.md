# Linux enroll

## Wat doet dit init-script

`init-device.sh` maakt een CachyOS-laptop klaar voor gebruik: Fleet-enrollment, KVT-huisstijl (login-achtergrond en applicatiestarter-iconen) en het KWin-effect KVT Energise.

## Vereisten

- Standaard CachyOS-installatie
- KDE Plasma als desktop environment
- Deze map compleet op de laptop (inclusief `enroll.sh`, `KVT-Energise/`, `backgr_1.png` en `kvtlogo.png`)
- Netwerkverbinding (voor Fleet-enrollment)
- Een account met sudo-rechten; voer het script uit als de desktop-gebruiker, niet als root-login

## Hoe te gebruiken

Open een terminal in deze map en start het script als de gebruiker wiens Plasma-sessie je wilt inrichten:

```bash
./init-device.sh
```

of:

```bash
bash init-device.sh
```

Het script vraagt zelf om sudo. Je kunt ook direct `sudo ./init-device.sh` gebruiken; KVT Energise en de taakbalk-iconen worden dan nog steeds op `$SUDO_USER` toegepast, niet op root.

Enrollment kan enkele minuten duren (Node.js, npm, fleetctl en het Fleet-package). Blijf bij de laptop tot het script `[INFO] Klaar. Device-init is uitgevoerd.` toont.

Controleer daarna:

- Systeeminstellingen → Animaties → Venster openen/sluiten: **KVT Energise**
- Login-scherm (na uitloggen): achtergrond `backgr_1`
- Alle panels: KVT-logo op de applicatiestarter

## Wat doet het script exact

Het script stopt bij de eerste fout (`set -euo pipefail`). Volgorde:

1. **Root**  
   Als het niet als root draait, herstart het zichzelf met `sudo -E bash`. Daarna wordt de desktop-gebruiker bepaald via `SUDO_USER`. Gebruikersgebonden stappen (KWin, Plasma) lopen als die gebruiker, met diens `HOME`, `XDG_*` en D-Bus-sessie.

2. **Fleet-enrollment (`enroll.sh`)**  
   Start `bash enroll.sh`. Dat normaliseert `/etc/os-release` (CachyOS → Arch, zodat Fleet het herkent), installeert Node.js/npm en fleetctl, bouwt een fleetd-package en installeert dat.

3. **KVT Energise**  
   Draait `KVT-Energise/install.sh` als de desktop-gebruiker. Het effect wordt gekopieerd naar `~/.local/share/kwin/effects/kwin6_effect_kvt_energise`.  
   Daarna wordt het **actief gezet** als venster openen/sluiten-animatie: in `~/.config/kwinrc` onder `[Plugins]` gaan concurrerende effecten in de exclusieve categorie `toplevel-open-close-animation` uit (`scale`, `glide`, `fade` en bekende Burn-My-Windows-varianten), en `kwin6_effect_kvt_energiseEnabled=true`. Via D-Bus (`org.kde.KWin`) wordt KWin herconfigureerd, oude effecten unloaded en KVT Energise geladen. In Systeeminstellingen → Animaties hoort **KVT Energise** geselecteerd te staan.

4. **Login-achtergrond**  
   Kopieert `backgr_1.png` naar `/usr/share/wallpapers/login-custom/backgr_1.png` (en indien aanwezig naar `/var/lib/plasmalogin/wallpapers/`).  
   Voor **Plasma Login Manager** schrijft het in `/etc/plasmalogin.conf`:

   ```
   [Greeter]
   WallpaperPluginId=org.kde.image

   [Greeter][Wallpaper][org.kde.image][General]
   Image=file:///usr/share/wallpapers/login-custom/backgr_1.png
   ```

   Als er een SDDM-thema staat, wordt dezelfde afbeelding ook in `theme.conf.user` gezet.

5. **Applicatiestarter-iconen**  
   Kopieert `kvtlogo.png` naar `~/.local/share/icons/kvtlogo.png`. In `~/.config/plasma-org.kde.plasma.desktop-appletsrc` krijgt elke Kickoff/Kicker/Kickerdash-applet in een panel `icon=` op dat pad. Als plasmashell draait, wordt hetzelfde live gezet via `evaluateScript` op alle panels.
