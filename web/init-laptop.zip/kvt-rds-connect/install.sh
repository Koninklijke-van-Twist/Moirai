#!/usr/bin/env bash
# Install KVT RDS Connect on Arch / CachyOS (and similar).
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
APP_SRC="$SCRIPT_DIR/kvt_rds_connect.py"
SHARE="${XDG_DATA_HOME:-$HOME/.local/share}/kvt-rds-connect"
BIN_DIR="${XDG_BIN_HOME:-$HOME/.local/bin}"
APP_DIR="${XDG_DATA_HOME:-$HOME/.local/share}/applications"

die() { echo "error: $*" >&2; exit 1; }

[[ -f "$APP_SRC" ]] || die "missing $APP_SRC (run this from the kvt-rds-connect folder)"

if [[ "${EUID:-$(id -u)}" -eq 0 && ( -z "${SUDO_USER:-}" || "$SUDO_USER" == "root" ) && "$HOME" == "/root" ]]; then
  die "refusing to install as root into /root — run as the desktop user, or via init-device.sh"
fi

echo "==> Checking dependencies"

need_pkgs=()
command -v xfreerdp3 >/dev/null 2>&1 || need_pkgs+=(freerdp)
command -v lsusb >/dev/null 2>&1 || need_pkgs+=(usbutils)

if ! python3 -c 'import gi; gi.require_version("Gtk", "3.0"); from gi.repository import Gtk' >/dev/null 2>&1; then
  need_pkgs+=(python-gobject gtk3)
fi

pacman_install() {
  if [[ "${EUID:-$(id -u)}" -eq 0 ]]; then
    pacman -S --needed --noconfirm "$@"
  elif command -v sudo >/dev/null 2>&1; then
    sudo pacman -S --needed --noconfirm "$@"
  else
    die "need packages: $* (no root/sudo)"
  fi
}

if ((${#need_pkgs[@]})); then
  if ! command -v pacman >/dev/null 2>&1; then
    die "need packages: ${need_pkgs[*]} (pacman not found — install them manually)"
  fi
  echo "Installing: ${need_pkgs[*]}"
  pacman_install "${need_pkgs[@]}"
else
  echo "Dependencies already present."
fi

command -v xfreerdp3 >/dev/null 2>&1 || die "xfreerdp3 still missing after install"
command -v python3 >/dev/null 2>&1 || die "python3 missing"

# Started with sudo? Files belong in the desktop user's home, not /root.
# Dependencies are installed by now, so re-run the rest as that user.
if [[ "${EUID:-$(id -u)}" -eq 0 && -n "${SUDO_USER:-}" && "$SUDO_USER" != "root" ]]; then
  TARGET_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
  [[ -n "$TARGET_HOME" && -d "$TARGET_HOME" ]] || die "cannot find home directory of $SUDO_USER"
  echo "==> Started with sudo: installing for $SUDO_USER in $TARGET_HOME"
  exec sudo -u "$SUDO_USER" env -u XDG_DATA_HOME -u XDG_BIN_HOME \
    HOME="$TARGET_HOME" USER="$SUDO_USER" LOGNAME="$SUDO_USER" \
    bash "$SCRIPT_DIR/install.sh"
fi

echo "==> Installing application files"
mkdir -p "$SHARE" "$BIN_DIR" "$APP_DIR"
install -m 755 "$APP_SRC" "$SHARE/kvt_rds_connect.py"

cat > "$BIN_DIR/kvt-rds-connect" << WRAP
#!/usr/bin/env bash
exec /usr/bin/python3 "$SHARE/kvt_rds_connect.py" "\$@"
WRAP
chmod 755 "$BIN_DIR/kvt-rds-connect"

sed "s|HOME_BIN|$BIN_DIR|g" "$SCRIPT_DIR/kvt-rds-connect.desktop.in" \
  > "$APP_DIR/kvt-rds-connect.desktop"
chmod 644 "$APP_DIR/kvt-rds-connect.desktop"

if command -v update-desktop-database >/dev/null 2>&1; then
  update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true
fi
# Refresh the KDE Plasma menu cache so the entry shows up without a re-login.
for kb in kbuildsycoca6 kbuildsycoca5; do
  if command -v "$kb" >/dev/null 2>&1; then
    "$kb" >/dev/null 2>&1 || true
    break
  fi
done

echo
echo "Installed."
echo "  App:     $SHARE/kvt_rds_connect.py"
echo "  Command: $BIN_DIR/kvt-rds-connect"
echo "  Menu:    KVT RDS Connect"
echo
if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
  echo "Note: $BIN_DIR is not in your PATH (the app menu entry works regardless)."
  echo "  fish:     fish_add_path ~/.local/bin"
  echo "  bash/zsh: export PATH=\"\$HOME/.local/bin:\$PATH\"  (in ~/.bashrc or ~/.zshrc)"
fi
echo "Launch with:  kvt-rds-connect"
