#!/usr/bin/env bash
# Install KVT RDP (FreeRDP connection picker) on Arch / CachyOS.
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
MODE="user"

usage() {
	cat <<USAGE
Usage: ./install.sh [--user|--system]

  --user    Install for the current desktop user (~/.local) [default]
            Also fine to start with sudo: it installs for the user who ran sudo.
  --system  Install for all users (/usr/local), needs sudo
USAGE
}

die() { echo "error: $*" >&2; exit 1; }

for arg in "$@"; do
	case "$arg" in
		--user) MODE=user ;;
		--system) MODE=system ;;
		-h|--help) usage; exit 0 ;;
		*) echo "Unknown option: $arg" >&2; usage; exit 1 ;;
	esac
done

is_root() { [ "${EUID:-$(id -u)}" -eq 0 ]; }
sudo_user() { [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; }

for f in bin/kvt-rdp share/applications/nl.kvt.rdp.desktop; do
	[ -f "$SCRIPT_DIR/$f" ] || die "missing $SCRIPT_DIR/$f (run this from the kvt-rdp folder)"
done

if [ "$MODE" = "system" ] && ! is_root; then
	exec sudo bash "$0" --system
fi

if [ "$MODE" = "user" ] && is_root && ! sudo_user && [ "$HOME" = "/root" ]; then
	die "refusing to install into /root: run as the desktop user, or use --system"
fi

echo "==> Checking dependencies"
need_pkgs=()
command -v kdialog >/dev/null 2>&1 || need_pkgs+=(kdialog)
command -v secret-tool >/dev/null 2>&1 || need_pkgs+=(libsecret)
command -v xfreerdp3 >/dev/null 2>&1 || need_pkgs+=(freerdp)

if [ "${#need_pkgs[@]}" -gt 0 ]; then
	command -v pacman >/dev/null 2>&1 || die "need packages: ${need_pkgs[*]} (pacman not found, install them manually)"
	echo "Installing: ${need_pkgs[*]}"
	if is_root; then
		pacman -S --needed --noconfirm "${need_pkgs[@]}"
	elif command -v sudo >/dev/null 2>&1; then
		sudo pacman -S --needed --noconfirm "${need_pkgs[@]}"
	else
		die "need packages: ${need_pkgs[*]} (no root/sudo)"
	fi
else
	echo "Dependencies already present."
fi
for c in kdialog secret-tool xfreerdp3; do
	command -v "$c" >/dev/null 2>&1 || die "$c still missing after install"
done

# User install started with sudo: the files belong in the desktop user's home,
# not /root. Dependencies are in place now, so re-run the rest as that user.
if [ "$MODE" = "user" ] && is_root && sudo_user; then
	TARGET_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
	[ -n "$TARGET_HOME" ] && [ -d "$TARGET_HOME" ] || die "cannot find home directory of $SUDO_USER"
	echo "==> Started with sudo: installing for $SUDO_USER in $TARGET_HOME"
	exec sudo -u "$SUDO_USER" env -u XDG_DATA_HOME \
		HOME="$TARGET_HOME" USER="$SUDO_USER" LOGNAME="$SUDO_USER" \
		bash "$SCRIPT_DIR/install.sh" --user
fi

if [ "$MODE" = "user" ]; then
	DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
	BIN_DIR="$HOME/.local/bin"
	APP_DIR="$DATA_HOME/applications"
	ICON_ROOT="$DATA_HOME/icons/hicolor"
else
	BIN_DIR="/usr/local/bin"
	APP_DIR="/usr/local/share/applications"
	ICON_ROOT="/usr/local/share/icons/hicolor"
fi

echo "==> Installing application files"
install -d "$BIN_DIR" "$APP_DIR"
install -Dm755 "$SCRIPT_DIR/bin/kvt-rdp" "$BIN_DIR/kvt-rdp"
install -Dm644 "$SCRIPT_DIR/share/applications/nl.kvt.rdp.desktop" "$APP_DIR/nl.kvt.rdp.desktop"

# Absolute Exec path, so the launcher works even when ~/.local/bin is not in PATH
if command -v desktop-file-edit >/dev/null 2>&1; then
	desktop-file-edit --set-key=Exec --set-value="$BIN_DIR/kvt-rdp" "$APP_DIR/nl.kvt.rdp.desktop"
else
	sed -i "s|^Exec=.*|Exec=$BIN_DIR/kvt-rdp|" "$APP_DIR/nl.kvt.rdp.desktop"
fi

for size in 256x256 512x512; do
	src="$SCRIPT_DIR/share/icons/hicolor/$size/apps/nl.kvt.rdp.png"
	[ -f "$src" ] || continue
	install -Dm644 "$src" "$ICON_ROOT/$size/apps/nl.kvt.rdp.png"
done

if [ "$MODE" = "user" ]; then
	# Old Downloads-based launcher
	rm -f "$APP_DIR/net.local.RDP.sh.desktop"
	# Misplaced copies from earlier installer versions (~/.local/share/share/...)
	rm -f "$HOME/.local/share/share/applications/nl.kvt.rdp.desktop" \
		"$HOME/.local/share/share/icons/hicolor/256x256/apps/nl.kvt.rdp.png" \
		"$HOME/.local/share/share/icons/hicolor/512x512/apps/nl.kvt.rdp.png"
fi

if command -v update-desktop-database >/dev/null 2>&1; then
	update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true
fi
if command -v gtk-update-icon-cache >/dev/null 2>&1 && [ -f "$ICON_ROOT/index.theme" ]; then
	gtk-update-icon-cache -f -t "$ICON_ROOT" >/dev/null 2>&1 || true
fi

# Refresh the KDE Plasma menu cache so "KVT RDP" shows up without a re-login.
refresh_menu() {
	local kb
	for kb in kbuildsycoca6 kbuildsycoca5; do
		command -v "$kb" >/dev/null 2>&1 || continue
		if is_root && sudo_user; then
			local h
			h="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
			sudo -u "$SUDO_USER" env HOME="$h" "$kb" >/dev/null 2>&1 || true
		elif ! is_root; then
			"$kb" >/dev/null 2>&1 || true
		fi
		return
	done
	if command -v xdg-desktop-menu >/dev/null 2>&1; then
		xdg-desktop-menu forceupdate >/dev/null 2>&1 || true
	fi
}
refresh_menu

if command -v desktop-file-validate >/dev/null 2>&1; then
	desktop-file-validate "$APP_DIR/nl.kvt.rdp.desktop" || die "desktop entry failed validation"
fi

printf '\nInstalled KVT RDP (%s)\n' "$MODE"
printf '  binary:  %s\n' "$BIN_DIR/kvt-rdp"
printf '  desktop: %s\n' "$APP_DIR/nl.kvt.rdp.desktop"
printf 'Search for "KVT RDP" in your app launcher.\n'
