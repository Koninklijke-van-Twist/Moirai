#!/usr/bin/env bash

set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENROLL_SCRIPT="$SCRIPT_DIR/enroll.sh"
KVT_INSTALL="$SCRIPT_DIR/KVT-Energise/install.sh"
KVT_EFFECT_ID="kwin6_effect_kvt_energise"
BACKGROUND_SRC="$SCRIPT_DIR/backgr_1.png"
LOGO_SRC="$SCRIPT_DIR/kvtlogo.png"

LOGIN_WALLPAPER_DIR="/usr/share/wallpapers/login-custom"
LOGIN_WALLPAPER_PATH="$LOGIN_WALLPAPER_DIR/backgr_1.png"
PLASMALOGIN_CONF="/etc/plasmalogin.conf"

TARGET_USER=""
TARGET_HOME=""
TARGET_UID=""

log() {
	printf '[INFO] %s\n' "$1"
}

warn() {
	printf '[WARN] %s\n' "$1" >&2
}

die() {
	printf '[ERROR] %s\n' "$1" >&2
	exit 1
}

require_root() {
	if [ "${EUID:-$(id -u)}" -ne 0 ]; then
		log "Dit script heeft root-rechten nodig. Probeer opnieuw met sudo..."
		if command -v sudo >/dev/null 2>&1; then
			exec sudo -E bash "$0" "$@"
		fi
		die "Kon geen sudo vinden. Start dit script als root."
	fi
}

resolve_target_user() {
	if [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
		TARGET_USER="$SUDO_USER"
	elif [ "${EUID:-$(id -u)}" -ne 0 ]; then
		TARGET_USER="$(id -un)"
	fi

	if [ -z "$TARGET_USER" ]; then
		warn "Geen desktop-gebruiker gevonden (SUDO_USER ontbreekt). KVT Energise en taakbalk-iconen worden overgeslagen."
		return
	fi

	TARGET_HOME="$(getent passwd "$TARGET_USER" | cut -d: -f6)"
	TARGET_UID="$(id -u "$TARGET_USER")"
	[ -n "$TARGET_HOME" ] || die "Kon home-directory van $TARGET_USER niet bepalen."
}

run_as_user() {
	if [ -z "$TARGET_USER" ]; then
		die "Geen doelgebruiker om commando als uit te voeren."
	fi

	if [ "$(id -un)" = "$TARGET_USER" ]; then
		"$@"
		return
	fi

	local runtime="/run/user/$TARGET_UID"
	sudo -u "$TARGET_USER" \
		--preserve-env=DISPLAY,WAYLAND_DISPLAY \
		env HOME="$TARGET_HOME" \
			USER="$TARGET_USER" \
			LOGNAME="$TARGET_USER" \
			XDG_RUNTIME_DIR="$runtime" \
			DBUS_SESSION_BUS_ADDRESS="unix:path=$runtime/bus" \
			XDG_CONFIG_HOME="$TARGET_HOME/.config" \
			XDG_DATA_HOME="$TARGET_HOME/.local/share" \
			"$@"
}

run_enroll() {
	[ -f "$ENROLL_SCRIPT" ] || die "enroll.sh niet gevonden: $ENROLL_SCRIPT"
	log "Start enroll.sh..."
	bash "$ENROLL_SCRIPT"
	log "enroll.sh is klaar."
}

kwin_plugin_ids_for_open_close() {
	local extra=(
		fade scale glide
		kwin4_effect_fade kwin4_effect_scale
		kwin6_effect_glide kwin6_effect_fade kwin6_effect_scale
		kwin6_effect_energize_a kwin6_effect_energize_b
		kwin6_effect_fire kwin6_effect_tv
		kwin6_effect_hexagon kwin6_effect_incinerate
	)
	local dir f id
	local dirs=(
		/usr/share/kwin-wayland/effects
		/usr/share/kwin-wayland/builtin-effects
		/usr/share/kwin/effects
		"$TARGET_HOME/.local/share/kwin/effects"
	)

	printf '%s\n' "${extra[@]}"

	for dir in "${dirs[@]}"; do
		[ -d "$dir" ] || continue
		while IFS= read -r f; do
			grep -q 'toplevel-open-close-animation' "$f" || continue
			id="$(awk -F'"' '/"Id":/ { print $4; exit }' "$f")"
			if [ -z "$id" ]; then
				id="$(basename "$f" .json)"
				if [ "$id" = "metadata" ]; then
					id="$(basename "$(dirname "$f")")"
				fi
			fi
			[ -n "$id" ] && printf '%s\n' "$id"
		done < <(find "$dir" -type f \( -name metadata.json -o -name '*.json' \) 2>/dev/null)
	done
}

kwin_write_plugin() {
	local plugin_id="$1" enabled="$2"
	run_as_user kwriteconfig6 --file kwinrc --group Plugins --key "${plugin_id}Enabled" "$enabled"
}

kwin_dbus() {
	if ! command -v qdbus6 >/dev/null 2>&1; then
		return 1
	fi
	run_as_user qdbus6 org.kde.KWin "$@" >/dev/null 2>&1 || true
}

activate_kvt_open_close_animation() {
	local plugin_id
	local seen="|"

	log "Zet KVT Energise als animatie bij venster openen/sluiten..."

	while IFS= read -r plugin_id; do
		[ -n "$plugin_id" ] || continue
		[[ "$seen" == *"|$plugin_id|"* ]] && continue
		seen+="$plugin_id|"
		if [ "$plugin_id" = "$KVT_EFFECT_ID" ]; then
			continue
		fi
		kwin_write_plugin "$plugin_id" false
		kwin_dbus /Effects org.kde.kwin.Effects.unloadEffect "$plugin_id"
	done < <(kwin_plugin_ids_for_open_close)

	kwin_write_plugin "$KVT_EFFECT_ID" true
	kwin_dbus /KWin org.kde.KWin.reconfigure
	kwin_dbus /Effects org.kde.kwin.Effects.loadEffect "$KVT_EFFECT_ID"
	kwin_dbus /Effects org.kde.kwin.Effects.reconfigureEffect "$KVT_EFFECT_ID"

	local enabled
	enabled="$(run_as_user kreadconfig6 --file kwinrc --group Plugins --key "${KVT_EFFECT_ID}Enabled")"
	if [ "$enabled" != "true" ]; then
		warn "KVT Energise staat niet op true in kwinrc (waarde: ${enabled:-leeg})."
		return
	fi
	log "KVT Energise is actief als venster openen/sluiten-animatie."
}

install_kvt_energise() {
	if [ -z "$TARGET_USER" ]; then
		warn "Sla KVT Energise over: geen desktop-gebruiker."
		return
	fi

	[ -f "$KVT_INSTALL" ] || die "KVT Energise install-script niet gevonden: $KVT_INSTALL"
	log "Installeer KVT Energise voor gebruiker $TARGET_USER..."
	run_as_user bash "$KVT_INSTALL"
	log "KVT Energise is geinstalleerd."
	activate_kvt_open_close_animation
}

current_sddm_theme() {
	local theme=""
	local file

	for file in /etc/sddm.conf /etc/sddm.conf.d/*.conf /usr/lib/sddm/sddm.conf.d/*.conf /etc/plasmalogin.conf; do
		[ -f "$file" ] || continue
		theme="$(awk -F= '
			$1 == "Current" {
				gsub(/\r/, "", $2)
				print $2
			}
		' "$file" | tail -n1)"
		if [ -n "$theme" ]; then
			printf '%s\n' "$theme"
			return
		fi
	done

	printf 'breeze\n'
}

set_login_background() {
	[ -f "$BACKGROUND_SRC" ] || die "Achtergrond niet gevonden: $BACKGROUND_SRC"

	log "Kopieer login-achtergrond naar $LOGIN_WALLPAPER_PATH"
	install -Dm644 "$BACKGROUND_SRC" "$LOGIN_WALLPAPER_PATH"

	if getent passwd plasmalogin >/dev/null 2>&1; then
		local pl_dir="/var/lib/plasmalogin/wallpapers"
		mkdir -p "$pl_dir"
		install -Dm644 "$BACKGROUND_SRC" "$pl_dir/backgr_1.png"
		chown plasmalogin:plasmalogin "$pl_dir/backgr_1.png" 2>/dev/null || true
	fi

	if [ -e /etc/plasmalogin.conf ] || command -v plasmalogin >/dev/null 2>&1; then
		log "Stel Plasma Login Manager achtergrond in..."
		if command -v kwriteconfig6 >/dev/null 2>&1; then
			kwriteconfig6 --file "$PLASMALOGIN_CONF" --group Greeter --key WallpaperPluginId org.kde.image
			kwriteconfig6 --file "$PLASMALOGIN_CONF" --group Greeter --group Wallpaper --group org.kde.image --group General --key Image "file://$LOGIN_WALLPAPER_PATH"
		else
			die "kwriteconfig6 niet gevonden; kan $PLASMALOGIN_CONF niet bijwerken."
		fi
		log "Plasma Login Manager gebruikt nu $LOGIN_WALLPAPER_PATH"
	fi

	local theme theme_dir
	theme="$(current_sddm_theme)"
	theme_dir="/usr/share/sddm/themes/$theme"
	if [ -d "$theme_dir" ]; then
		log "Stel SDDM-thema '$theme' achtergrond in via theme.conf.user..."
		cat > "$theme_dir/theme.conf.user" <<EOF
[General]
background=$LOGIN_WALLPAPER_PATH
type=image
EOF
	fi
}

set_launcher_icons() {
	if [ -z "$TARGET_USER" ]; then
		warn "Sla taakbalk-iconen over: geen desktop-gebruiker."
		return
	fi

	[ -f "$LOGO_SRC" ] || die "Logo niet gevonden: $LOGO_SRC"

	local icon_dest="$TARGET_HOME/.local/share/icons/kvtlogo.png"
	local appletsrc="$TARGET_HOME/.config/plasma-org.kde.plasma.desktop-appletsrc"

	log "Kopieer applicatiestarter-icoon naar $icon_dest"
	install -o "$TARGET_USER" -g "$TARGET_USER" -Dm644 "$LOGO_SRC" "$icon_dest"

	if [ ! -f "$appletsrc" ]; then
		warn "Geen Plasma applets-config gevonden ($appletsrc). Probeer alleen live Plasma-update."
	else
		log "Zet kvtlogo.png op alle applicatiestarters in $appletsrc"
		local section="" plugin="" updated=0
		while IFS= read -r line || [ -n "$line" ]; do
			case "$line" in
				\[*\])
					section="${line#\[}"
					section="${section%\]}"
					plugin=""
					;;
				plugin=org.kde.plasma.kickoff|plugin=org.kde.plasma.kicker|plugin=org.kde.plasma.kickerdash)
					plugin="${line#plugin=}"
					case "$section" in
						Containments\]\[*\]\[Applets\]\[*)
							local group_args=()
							local part rest="$section"
							while [ -n "$rest" ]; do
								part="${rest%%][*}"
								if [ "$part" = "$rest" ]; then
									group_args+=(--group "$rest")
									break
								fi
								group_args+=(--group "$part")
								rest="${rest#*][}"
							done
							run_as_user kwriteconfig6 \
								--file plasma-org.kde.plasma.desktop-appletsrc \
								"${group_args[@]}" \
								--group Configuration \
								--group General \
								--key icon "$icon_dest"
							updated=$((updated + 1))
							log "  - $plugin ($section) -> $icon_dest"
							;;
					esac
					;;
			esac
		done < "$appletsrc"

		if [ "$updated" -eq 0 ]; then
			warn "Geen applicatiestarters (kickoff/kicker/kickerdash) in appletsrc gevonden."
		else
			log "$updated applicatiestarter(s) bijgewerkt in config."
		fi
	fi

	apply_launcher_icons_live "$icon_dest"
}

apply_launcher_icons_live() {
	local icon_dest="$1"
	local js

	if ! run_as_user bash -c 'command -v qdbus6 >/dev/null && qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "true" >/dev/null 2>&1'; then
		warn "plasmashell is niet bereikbaar; iconen worden bij de volgende login/sessie-herstart zichtbaar."
		return
	fi

	log "Pas applicatiestarter-iconen live toe in plasmashell..."
	js="$(cat <<EOF
var icon = "$icon_dest";
var types = {
    "org.kde.plasma.kickoff": true,
    "org.kde.plasma.kicker": true,
    "org.kde.plasma.kickerdash": true
};
var pans = panels();
for (var i = 0; i < pans.length; ++i) {
    var widgets = pans[i].widgets();
    for (var j = 0; j < widgets.length; ++j) {
        var w = widgets[j];
        if (types[w.type]) {
            w.currentConfigGroup = ["General"];
            w.writeConfig("icon", icon);
            try { w.reloadConfig(); } catch (e) {}
        }
    }
}
EOF
)"
	run_as_user qdbus6 org.kde.plasmashell /PlasmaShell org.kde.PlasmaShell.evaluateScript "$js" >/dev/null
	log "Live Plasma-update aangevraagd."
}

main() {
	require_root "$@"
	resolve_target_user

	[ -f "$BACKGROUND_SRC" ] || die "Achtergrond niet gevonden: $BACKGROUND_SRC"
	[ -f "$LOGO_SRC" ] || die "Logo niet gevonden: $LOGO_SRC"

	run_enroll
	install_kvt_energise
	set_login_background
	set_launcher_icons

	log "Klaar. Device-init is uitgevoerd."
}

main "$@"
