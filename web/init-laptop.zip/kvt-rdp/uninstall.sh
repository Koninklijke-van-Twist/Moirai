#!/usr/bin/env bash
set -euo pipefail

MODE="user"
for arg in "$@"; do
	case "$arg" in
		--user) MODE=user ;;
		--system) MODE=system ;;
	esac
done

is_root() { [ "${EUID:-$(id -u)}" -eq 0 ]; }

if [ "$MODE" = "system" ] && ! is_root; then
	exec sudo bash "$0" --system
fi

# User uninstall started with sudo: act on the desktop user's home, not /root.
if [ "$MODE" = "user" ] && is_root && [ -n "${SUDO_USER:-}" ] && [ "$SUDO_USER" != "root" ]; then
	TARGET_HOME="$(getent passwd "$SUDO_USER" | cut -d: -f6)"
	exec sudo -u "$SUDO_USER" env -u XDG_DATA_HOME HOME="$TARGET_HOME" bash "$0" --user
fi

if [ "$MODE" = "user" ]; then
	DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"
	BIN_DIR="$HOME/.local/bin"
	APP_DIR="$DATA_HOME/applications"
	ICON_ROOT="$DATA_HOME/icons/hicolor"
	# Misplaced copies from earlier installer versions
	rm -f "$HOME/.local/share/share/applications/nl.kvt.rdp.desktop" \
		"$HOME/.local/share/share/icons/hicolor/256x256/apps/nl.kvt.rdp.png" \
		"$HOME/.local/share/share/icons/hicolor/512x512/apps/nl.kvt.rdp.png"
else
	BIN_DIR="/usr/local/bin"
	APP_DIR="/usr/local/share/applications"
	ICON_ROOT="/usr/local/share/icons/hicolor"
fi

rm -f "$BIN_DIR/kvt-rdp"
rm -f "$APP_DIR/nl.kvt.rdp.desktop"
rm -f "$ICON_ROOT"/256x256/apps/nl.kvt.rdp.png
rm -f "$ICON_ROOT"/512x512/apps/nl.kvt.rdp.png

command -v update-desktop-database >/dev/null 2>&1 && update-desktop-database "$APP_DIR" >/dev/null 2>&1 || true
if ! is_root; then
	for kb in kbuildsycoca6 kbuildsycoca5; do
		command -v "$kb" >/dev/null 2>&1 && { "$kb" >/dev/null 2>&1 || true; break; }
	done
fi
printf 'Uninstalled KVT RDP (%s)\n' "$MODE"
